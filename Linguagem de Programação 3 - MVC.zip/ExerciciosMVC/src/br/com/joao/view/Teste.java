package br.com.joao.view;

import br.com.joao.controller.MetodosCompra;
/**
 * 
 * 
 * @author Joao Victor
 * @version 1.0
 * @since 2020
 * 
 */

public class Teste {
	/**
	 * M�todo principal
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) {
		
		MetodosCompra mc = new MetodosCompra();
		
		mc.fazerPedido();
	}

}

