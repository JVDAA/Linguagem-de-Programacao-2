package br.com.joao.model;

/**
 * 
 * 
 * @author Joao Victor
 * @version 1.0
 * @since 2020
 * 
 */

public class Armazem {
	private int codigo;
	private String endereco;
	private int numeroarmazem;
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public int getNumeroarmazem() {
		return numeroarmazem;
	}
	public void setNumeroarmazem(int numeroarmazem) {
		this.numeroarmazem = numeroarmazem;
	}
}
